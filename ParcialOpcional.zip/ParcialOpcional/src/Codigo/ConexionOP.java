package Codigo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionOP {
    private static final String URL = "jdbc:mysql://localhost:3306/finacierabd?serverTimezone=UTC";
    private static final String USER = "root"; // Cambia si tienes otro usuario
    private static final String PASSWORD = ""; // Deja vacío si no tienes contraseña

    public static Connection conectar() {
        Connection conexion = null;
        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver"); 

            // Intentar conectar
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Conexión exitosa a la base de datos.");
        } catch (ClassNotFoundException e) {
            System.out.println("❌ Error: Driver de MySQL no encontrado.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ Error de conexión a la base de datos.");
            e.printStackTrace();
        }
        return conexion;
    }
}
