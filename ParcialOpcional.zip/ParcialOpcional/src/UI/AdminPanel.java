package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import Codigo.ConexionOP;


public class AdminPanel extends javax.swing.JFrame {
    
    private JTextField txtNit, txtNombre, txtDireccion, txtTelefono;
    private JButton btnRegistrar;

    public AdminPanel() {
        setTitle("Panel Administrador");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        txtNit = new JTextField();
        txtNombre = new JTextField();
        txtDireccion = new JTextField();
        txtTelefono = new JTextField();
        btnRegistrar = new JButton("Registrar Entidad");

        add(new JLabel("NIT:"));
        add(txtNit);
        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Dirección:"));
        add(txtDireccion);
        add(new JLabel("Teléfono:"));
        add(txtTelefono);
        add(new JLabel(""));
        add(btnRegistrar);

        btnRegistrar.addActionListener(e -> registrarEntidad());

        setVisible(true);
        
    }

private void registrarEntidad() {
        String nit = txtNit.getText();
        String nombre = txtNombre.getText();
        String direccion = txtDireccion.getText();
        String telefono = txtTelefono.getText();

        String sql = "INSERT INTO entidad_financiera (id, nit, nombre, direccion, telefono) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionOP.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nit);
            stmt.setString(2, nombre);
            stmt.setString(3, direccion);
            stmt.setString(4, telefono);

            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Dato insertado correctamente en la BD.");
            } else {
                JOptionPane.showMessageDialog(this, "Dato NO ingresado a la BD.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al insertar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AdminPanel().setVisible(true);
        });
    }

}
