package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import Codigo.ConexionOP;

public class SecretarioPanel extends JFrame {
    private JTextField txtCodigo, txtNit, txtDia, txtFecha, txtHora, txtValor;
    private JButton btnRegistrar;

    public SecretarioPanel() {
        setTitle("Panel del Secretario");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(8, 2, 5, 5));

        // Componentes
        txtCodigo = new JTextField();
        txtNit = new JTextField();
        txtDia = new JTextField();
        txtFecha = new JTextField(); // formato: YYYY-MM-DD
        txtHora = new JTextField();  // formato: HH:MM
        txtValor = new JTextField();
        btnRegistrar = new JButton("Registrar Solicitud");

        add(new JLabel("Código:"));
        add(txtCodigo);
        add(new JLabel("NIT de la Entidad:"));
        add(txtNit);
        add(new JLabel("Día de Recolección:"));
        add(txtDia);
        add(new JLabel("Fecha (YYYY-MM-DD):"));
        add(txtFecha);
        add(new JLabel("Hora (HH:MM):"));
        add(txtHora);
        add(new JLabel("Valor:"));
        add(txtValor);
        add(new JLabel(""));
        add(btnRegistrar);

        // Acción del botón
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarSolicitud();
            }
        });
    }

    private void registrarSolicitud() {
        String codigo = txtCodigo.getText().trim();
        String nit = txtNit.getText().trim();
        String dia = txtDia.getText().trim();
        String fecha = txtFecha.getText().trim();
        String hora = txtHora.getText().trim();
        String valorTexto = txtValor.getText().trim();

        if (codigo.isEmpty() || nit.isEmpty() || dia.isEmpty() || fecha.isEmpty() || hora.isEmpty() || valorTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.");
            return;
        }

        double valor;
        try {
            valor = Double.parseDouble(valorTexto);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Valor debe ser numérico.");
            return;
        }

        String sql = "INSERT INTO solicitudes (codigo, nit_entidad, dia, fecha, hora, valor) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionOP.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, codigo);
            stmt.setString(2, nit);
            stmt.setString(3, dia);
            stmt.setString(4, fecha);
            stmt.setString(5, hora);
            stmt.setDouble(6, valor);

            int filas = stmt.executeUpdate();

            if (filas > 0) {
                JOptionPane.showMessageDialog(this, "Dato insertado correctamente en la BD.");
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Dato NO ingresado a la BD.");
            }

        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(this, "El NIT ingresado no existe en la tabla de entidades.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error en la base de datos: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNit.setText("");
        txtDia.setText("");
        txtFecha.setText("");
        txtHora.setText("");
        txtValor.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SecretarioPanel().setVisible(true));
    }
}
