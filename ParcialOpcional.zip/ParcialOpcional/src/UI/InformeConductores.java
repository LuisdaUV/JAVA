package UI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import Codigo.ConexionOP;


public class InformeConductores extends JFrame {
    private JTable tabla;
    private DefaultTableModel modelo;

    public InformeConductores() {
        setTitle("Informe para Conductores");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 400);
        setLocationRelativeTo(null);
        
        modelo = new DefaultTableModel();
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);

        modelo.addColumn("Código");
        modelo.addColumn("NIT Entidad");
        modelo.addColumn("Nombre Entidad");
        modelo.addColumn("Día");
        modelo.addColumn("Fecha");
        modelo.addColumn("Hora");
        modelo.addColumn("Valor");
        modelo.addColumn("Dirección");

        cargarDatos();

        add(scroll, BorderLayout.CENTER);
    }

    private void cargarDatos() {
        String sql = """
            SELECT s.codigo, e.nit, e.nombre, s.dia, s.fecha, s.hora, s.valor, e.direccion
            FROM solicitudes s
            JOIN entidades e ON s.nit_entidad = e.nit
            ORDER BY FIELD(LOWER(s.dia), 'lunes','martes','miércoles','miercoles','jueves','viernes','sábado','sabado','domingo')
        """;

        try (Connection conn = ConexionOP.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            boolean hayDatos = false;

            while (rs.next()) {
                hayDatos = true;
                modelo.addRow(new Object[]{
                    rs.getString("codigo"),
                    rs.getString("nit"),
                    rs.getString("nombre"),
                    rs.getString("dia"),
                    rs.getString("fecha"),
                    rs.getString("hora"),
                    rs.getDouble("valor"),
                    rs.getString("direccion")
                });
            }

            if (!hayDatos) {
                JOptionPane.showMessageDialog(this, "NO hay datos en la tabla.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando datos: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InformeConductores().setVisible(true));
    }
}

